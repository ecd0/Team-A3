#!/usr/bin/python
from Drone import Drone  
raw_input('Press Enter')
print "Running..."
var = Drone()
print "done"

