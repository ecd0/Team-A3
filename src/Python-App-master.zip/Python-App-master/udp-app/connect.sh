#!/bin/bash
mavproxy.py --sitl=192.168.1.132:14550 --out=127.0.0.1:5760 
